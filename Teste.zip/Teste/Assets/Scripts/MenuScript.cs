﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MenuScript : MonoBehaviour
{

	// Use this for initialization
	void OnGUI ()
	{
		const int larguraBotao = 84;
		const int alturaBotao = 60;

		if (GUI.Button (
			   new Rect (Screen.width / 2 - (larguraBotao / 2), 
				   Screen.height / 2 - (alturaBotao / 2), larguraBotao, alturaBotao), 
			   "Jogar!"))
		{

			Application.LoadLevel ("");


		}
		
	}
}
